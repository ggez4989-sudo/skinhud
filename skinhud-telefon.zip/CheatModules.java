package pl.skinhud;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Moduly do uzytku w singlu / na wlasnym serwerze / u znajomych za zgoda.
 * Menu: Right Shift. Klawisze skrotow (zmienisz w Sterowanie -> Skin HUD):
 *   B Fullbright, N AutoSprint, V Fly, M InventoryMove, H koordynaty HUD
 * Ustawienia zapisuja sie w config/skinhud.properties.
 */
public class CheatModules {

    public static final int FULLBRIGHT = 0, AUTOSPRINT = 1, FLY = 2, INVMOVE = 3, COORDS = 4;
    public static final String[] NAMES = {"Fullbright", "AutoSprint", "Fly", "InventoryMove", "Koordy HUD"};
    public static final int COUNT = NAMES.length;

    private static final boolean[] state = new boolean[COUNT];
    private static KeyBinding[] keys = new KeyBinding[COUNT];
    private static KeyBinding menuKey;
    private static boolean flyApplied, fullbrightApplied;

    public static boolean get(int id) { return state[id]; }

    public static void set(int id, boolean on) {
        state[id] = on;
        save();
    }

    public static void init() {
        state[COORDS] = true; // domyslnie wlaczone
        load();

        int[] defaults = {GLFW.GLFW_KEY_B, GLFW.GLFW_KEY_N, GLFW.GLFW_KEY_V, GLFW.GLFW_KEY_M, GLFW.GLFW_KEY_H};
        String[] ids = {"fullbright", "autosprint", "fly", "inventorymove", "coordshud"};
        for (int i = 0; i < COUNT; i++) {
            keys[i] = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                    "key.skinhud." + ids[i], InputUtil.Type.KEYSYM, defaults[i], "key.categories.skinhud"));
        }
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.skinhud.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.skinhud"));

        ClientTickEvents.START_CLIENT_TICK.register(CheatModules::startTick);
        ClientTickEvents.END_CLIENT_TICK.register(CheatModules::endTick);
        HudRenderCallback.EVENT.register(CheatModules::render);
    }

    // ---------- zapis / odczyt ustawien ----------
    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("skinhud.properties");
    }

    private static void load() {
        try {
            Path p = configPath();
            if (!Files.exists(p)) return;
            Properties props = new Properties();
            try (InputStream in = Files.newInputStream(p)) { props.load(in); }
            for (int i = 0; i < COUNT; i++) {
                String v = props.getProperty(NAMES[i].replace(' ', '_'));
                if (v != null) state[i] = Boolean.parseBoolean(v);
            }
        } catch (Exception ignored) {}
    }

    private static void save() {
        try {
            Properties props = new Properties();
            for (int i = 0; i < COUNT; i++) props.setProperty(NAMES[i].replace(' ', '_'), String.valueOf(state[i]));
            try (OutputStream out = Files.newOutputStream(configPath())) { props.store(out, "Skin HUD"); }
        } catch (Exception ignored) {}
    }

    // ---------- InventoryMove: przed tickiem gracza ----------
    private static void startTick(MinecraftClient client) {
        if (!state[INVMOVE] || client.player == null) return;
        if (!(client.currentScreen instanceof HandledScreen<?> screen)) return;
        if (screen.getFocused() instanceof TextFieldWidget) return;

        long window = client.getWindow().getHandle();
        KeyBinding[] move = {
                client.options.forwardKey, client.options.backKey,
                client.options.leftKey, client.options.rightKey,
                client.options.jumpKey, client.options.sprintKey
        };
        for (KeyBinding k : move) {
            int code = InputUtil.fromTranslationKey(k.getBoundKeyTranslationKey()).getCode();
            k.setPressed(InputUtil.isKeyPressed(window, code));
        }
    }

    // ---------- reszta ----------
    private static void endTick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null) {
            flyApplied = false;
            fullbrightApplied = false;
            return;
        }

        // menu
        while (menuKey.wasPressed()) {
            if (client.currentScreen == null) client.setScreen(new ModuleMenuScreen());
        }
        // skroty
        for (int i = 0; i < COUNT; i++) {
            while (keys[i].wasPressed()) {
                set(i, !state[i]);
                player.sendMessage(Text.literal(NAMES[i] + ": " + (state[i] ? "WLACZONE" : "wylaczone")), true);
            }
        }

        // Fullbright (efekt tylko po stronie klienta)
        if (state[FULLBRIGHT]) {
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
            fullbrightApplied = true;
        } else if (fullbrightApplied) {
            player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            fullbrightApplied = false;
        }

        // AutoSprint
        if (state[AUTOSPRINT]
                && client.options.forwardKey.isPressed()
                && !player.isSneaking()
                && !player.horizontalCollision
                && !player.isUsingItem()
                && (player.getHungerManager().getFoodLevel() > 6 || player.getAbilities().allowFlying)) {
            player.setSprinting(true);
        }

        // Fly: lot jak w trybie kreatywnym, normalne sterowanie postacia
        if (state[FLY]) {
            if (!flyApplied) {
                player.getAbilities().allowFlying = true;
                player.getAbilities().flying = true;
                flyApplied = true;
            }
            player.getAbilities().allowFlying = true;
            player.fallDistance = 0;
        } else if (flyApplied) {
            if (!player.isCreative() && !player.isSpectator()) {
                player.getAbilities().allowFlying = false;
                player.getAbilities().flying = false;
            }
            flyApplied = false;
        }
    }

    // ---------- HUD ----------
    private static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || client.options.hudHidden) return;

        // lista wlaczonych modulow (prawy gorny rog)
        int sw = client.getWindow().getScaledWidth();
        int y = 4;
        for (int i = 0; i < COUNT - 1; i++) { // bez "Koordy HUD"
            if (!state[i]) continue;
            int w = client.textRenderer.getWidth(NAMES[i]);
            ctx.drawTextWithShadow(client.textRenderer, NAMES[i], sw - w - 4, y, 0xFF55FF55);
            y += 10;
        }

        // koordynaty pod okienkiem ze skinem
        if (state[COORDS] && client.currentScreen == null) {
            String biome = client.world == null ? "?" :
                    client.world.getBiome(player.getBlockPos()).getKey()
                            .map(k -> k.getValue().getPath()).orElse("?");
            String[] lines = {
                    String.format("XYZ: %.1f %.1f %.1f", player.getX(), player.getY(), player.getZ()),
                    "Biom: " + biome,
                    "FPS: " + client.getCurrentFps()
            };
            int ly = 90;
            for (String line : lines) {
                ctx.drawTextWithShadow(client.textRenderer, line, 5, ly, 0xFFFFFFFF);
                ly += 10;
            }
        }
    }
}
