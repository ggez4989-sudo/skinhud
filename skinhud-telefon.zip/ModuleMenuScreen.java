package pl.skinhud;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Menu na Right Shift: dwie kolumny przyciskow z modulami + przycisk listy ignorowanych nickow. */
public class ModuleMenuScreen extends Screen {

    private static final int BTN_W = 150, BTN_H = 20, GAP = 24;

    public ModuleMenuScreen() {
        super(Text.literal("Skin HUD - moduly"));
    }

    private static Text label(int id) {
        return Text.literal(CheatModules.NAMES[id] + ": " + (CheatModules.get(id) ? "ON" : "OFF"));
    }

    private int startY() {
        int rows = (CheatModules.COUNT + 1) / 2 + 1;
        return this.height / 2 - (rows * GAP) / 2 + 8;
    }

    @Override
    protected void init() {
        int leftX = this.width / 2 - BTN_W - 3;
        int rightX = this.width / 2 + 3;
        int y0 = startY();
        for (int i = 0; i < CheatModules.COUNT; i++) {
            final int id = i;
            int x = (i % 2 == 0) ? leftX : rightX;
            int y = y0 + (i / 2) * GAP;
            this.addDrawableChild(ButtonWidget.builder(label(id), b -> {
                CheatModules.set(id, !CheatModules.get(id));
                b.setMessage(label(id));
            }).dimensions(x, y, BTN_W, BTN_H).build());
        }
        int rows = (CheatModules.COUNT + 1) / 2;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Sonar: lista ignorowanych nickow..."),
                b -> this.client.setScreen(new IgnoreScreen()))
                .dimensions(leftX, y0 + rows * GAP, BTN_W * 2 + 6, BTN_H).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, startY() - 14, 0xFFFFFFFF);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            this.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
