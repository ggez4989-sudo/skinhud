package pl.skinhud;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Menu otwierane Right Shiftem: klikasz modul, zeby go wlaczyc/wylaczyc. */
public class ModuleMenuScreen extends Screen {

    private static final int BTN_W = 160, BTN_H = 20, GAP = 24;

    public ModuleMenuScreen() {
        super(Text.literal("Skin HUD - moduly"));
    }

    private static Text label(int id) {
        return Text.literal(CheatModules.NAMES[id] + ": " + (CheatModules.get(id) ? "ON" : "OFF"));
    }

    @Override
    protected void init() {
        int x = this.width / 2 - BTN_W / 2;
        int startY = this.height / 2 - (CheatModules.COUNT * GAP) / 2;
        for (int i = 0; i < CheatModules.COUNT; i++) {
            final int id = i;
            ButtonWidget button = ButtonWidget.builder(label(id), b -> {
                CheatModules.set(id, !CheatModules.get(id));
                b.setMessage(label(id));
            }).dimensions(x, startY + i * GAP, BTN_W, BTN_H).build();
            this.addDrawableChild(button);
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        int startY = this.height / 2 - (CheatModules.COUNT * GAP) / 2;
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, startY - 18, 0xFFFFFFFF);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            this.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
