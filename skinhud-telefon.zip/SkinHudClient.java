package pl.skinhud;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;

public class SkinHudClient implements ClientModInitializer {

    // Pozycja i rozmiar okienka w lewym gornym rogu (w pikselach GUI)
    private static final int X = 5;
    private static final int Y = 5;
    private static final int WIDTH = 50;
    private static final int HEIGHT = 80;
    private static final int SIZE = 30; // wielkosc modelu

    @Override
    public void onInitializeClient() {
        CheatModules.init();
        HudRenderCallback.EVENT.register((DrawContext context, net.minecraft.client.render.RenderTickCounter tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            ClientPlayerEntity player = client.player;

            // nie rysuj, gdy nie ma gracza, jest otwarty ekran albo F1 (ukryty HUD)
            if (player == null || client.options.hudHidden || client.currentScreen != null) {
                return;
            }

            // polprzezroczyste tlo
            context.fill(X, Y, X + WIDTH, Y + HEIGHT, 0x80000000);

            // Rysuje prawdziwy model gracza z jego skinem.
            // Animacje (chodzenie, bieg, skradanie, plywanie, skok) dzieja sie na zywo.
            // mouseX/mouseY ustawione na srodek okienka => postac patrzy prosto na nas.
            float centerX = X + WIDTH / 2f;
            float centerY = Y + HEIGHT / 2f - 20f;

            InventoryScreen.drawEntity(
                    context,
                    X, Y, X + WIDTH, Y + HEIGHT,
                    SIZE,
                    0.0625f,
                    centerX, centerY,
                    player
            );
        });
    }
}
