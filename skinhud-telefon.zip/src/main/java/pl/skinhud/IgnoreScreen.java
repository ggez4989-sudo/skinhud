package pl.skinhud;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;

/** Lista nickow, przed ktorymi sonar Cie NIE ostrzega. Wpisz nick i kliknij Dodaj; klik na nick usuwa go. */
public class IgnoreScreen extends Screen {

    private TextFieldWidget field;

    public IgnoreScreen() {
        super(Text.literal("Sonar - ignorowane nicki"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;

        field = new TextFieldWidget(this.textRenderer, cx - 100, 36, 140, 20, Text.literal("Nick"));
        field.setMaxLength(16);
        field.setPlaceholder(Text.literal("nick gracza"));
        this.addDrawableChild(field);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Dodaj"), b -> {
            String nick = field.getText().trim();
            if (!nick.isEmpty()) {
                CheatModules.addIgnored(nick);
                this.clearAndInit();
            }
        }).dimensions(cx + 45, 36, 55, 20).build());

        int y = 64;
        for (String nick : new ArrayList<>(CheatModules.ignored())) {
            this.addDrawableChild(ButtonWidget.builder(Text.literal(nick + "   [usun]"), b -> {
                CheatModules.removeIgnored(nick);
                this.clearAndInit();
            }).dimensions(cx - 100, y, 200, 20).build());
            y += 22;
        }

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Wroc"),
                b -> this.client.setScreen(new ModuleMenuScreen()))
                .dimensions(cx - 100, Math.min(y + 6, this.height - 26), 200, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 14, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                "Sonar nie ostrzega o tych nickach", this.width / 2, 25, 0xFFAAAAAA);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
